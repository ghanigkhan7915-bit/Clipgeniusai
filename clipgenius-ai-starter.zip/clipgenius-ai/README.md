# ClipGenius AI — starter project

## What this first build does
- Lets a user select a video stored on their device.
- Previews the video.
- Exports one selected time range as a WebM clip using browser MediaRecorder.
- Works as a simple mobile-first web app when hosted over HTTPS.

## Important limitations
- This starter does NOT download videos from YouTube URLs.
- It does NOT yet use AI to detect highlights or create automatic captions.
- Export depends on browser support for `HTMLVideoElement.captureStream` and `MediaRecorder`; use a recent Chrome browser.
- Process only videos you own or have permission to use.

## Publish with GitHub Pages
1. Extract this ZIP.
2. In your GitHub repository, choose Add file -> Upload files.
3. Upload `index.html` and `README.md` (not the ZIP itself).
4. Commit the changes to `main`.
5. Open repository Settings -> Pages.
6. Under Build and deployment, select Deploy from a branch, choose `main` and `/ (root)`, then Save.
7. Wait for the Pages URL to appear, then open it on your Android phone.

This is a frontend starter. AI highlight detection and server-side processing require a separate backend/service.
